// the old website uses just css hover on row, which doesn't work in IE6... for now, use that
//$(document).ready(function(){
//    $('table.exploit_list tr > *').hover(function(){
//        $(this).parent().addClass('hovered')}, function() {
//        $(this).parent().removeClass('hovered');
//    });
//});

jQuery(document).ready(function(){
    jQuery(function () {
        jQuery('[data-toggle="popover"]').popover({'html': true})
    })
    jQuery(function () {
        jQuery('[data-toggle="tooltip"]').tooltip()
    })
});

function checkSubmitForm()
{
	var errors = false;

	var author		= $('#author').val();
	var description	= $('#description').val();
	var platform	= parseInt($('#platform').val());
	var type		= parseInt($('#type').val());
	var code		= $('#code').val();

	if (author.length == 0) {
		jQuery('#author').css('border', '1px solid red');
		errors = true;
	} else {
		jQuery('#author').css('border', '0');
	}
	if (description.length == 0) {
		jQuery('#description').css('border', '1px solid red');
		errors = true;
	} else {
		jQuery('#description').css('border', '0');
	}
	if (platform <= 0) {
		jQuery('#platform').css('border', '1px solid red');
		errors = true;
	} else {
		jQuery('#platform').css('border', '0');
	}
	if (type <= 0) {
		jQuery('#type').css('border', '1px solid red');
		errors = true;
	} else {
		jQuery('#type').css('border', '0');
	}
	if (code.length == 0) {
		jQuery('#code').css('border', '1px solid red');
		errors = true;
	} else {
		jQuery('#code').css('border', '0');
	}
	return !errors;
}

function exp_checkIfUsernameExists()
{
	var username = jQuery('#username').val();
	var ajax_options = {
		beforeSend: function()
		{
			jQuery('#throbber').removeClass('display-none');
		},
		complete: function()
		{
			jQuery('#throbber').addClass('display-none');
		},
		error: function(XMLHttpRequest, textStatus, errorThrown)
		{
			alert('There was an error (5) during the request. Please try again later!');
		},
		success: function(html, textStatus)
		{
			if (html == 'ok') {
				jQuery('#loginname_ok').css('display', 'inline');
			} else {
				jQuery('#loginname_ok').css('display', 'none');
				alert(html)
			}
			return false;
		},
		timeout: '100000',
		type: 'POST',
		dataType: 'HTML',
		data: 'action=exploit_loginname_exists&username='+escape(username),
		url: ajaxurl
	};
	jQuery.ajax(ajax_options);
	return false;
}

function checkSelectedTypeOnSearchForm()
{
	var type = jQuery("#type").val();
	if (type == 5) {
		jQuery('#search_form_language').show();
	} else {
		jQuery('#search_form_language').hide();
		jQuery('#p_language').val("0")
	}
}

function toogleAdvanced()
{
    jQuery("#advanced-search").slideToggle();
}

function removeEmptyValuesFromGet()
{
    var fields = ["description", "text", "cve", "author", "e_author", "platform", "type", "lang_id", "port", "osvdb", "dos", "msf", "papers"]; //  ,"apps", "verified"
    for (var i =0; i < fields.length; i++) {
        if (jQuery('form#searchForm input[name="'+fields[i]+'"]').length == 1 && jQuery('form#searchForm input[name="'+fields[i]+'"]').attr('type').toLowerCase() == 'text') {
            var val = jQuery('form#searchForm input[name="'+fields[i]+'"]').val();
            if (val.length == 0) {
                jQuery('form#searchForm input[name="'+fields[i]+'"]').attr("disabled", "disabled");
            } else {
            	jQuery('form#searchForm input[name="'+fields[i]+'"]').val(val.trim());
            }

        } else if (jQuery('form#searchForm select[name="'+fields[i]+'"]').is('select')) {
            if (jQuery('form#searchForm select[name="'+fields[i]+'"] option:selected').val() == 0) {
                jQuery('form#searchForm select[name="'+fields[i]+'"]').attr("disabled", "disabled");
            }

        } else if (jQuery('form#searchForm input[name="'+fields[i]+'"]').attr('type') == 'checkbox') {
        	if (jQuery('form#searchForm input[name="'+fields[i]+'"]').prop('checked')) {
        		jQuery('form#searchForm input[name="'+fields[i]+'"]').prop('checked', false);
        	} else {
        		jQuery('form#searchForm input[name="'+fields[i]+'"]').prop('checked', true);
        	}

        }
    }
    return true;
}